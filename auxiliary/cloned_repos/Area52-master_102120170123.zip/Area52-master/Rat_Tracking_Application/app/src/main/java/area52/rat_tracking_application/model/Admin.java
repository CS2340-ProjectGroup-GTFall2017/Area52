package area52.rat_tracking_application.model;

import area52.rat_tracking_application.controllers.RegistrationActivity;

/**
 * Class representing an Admin, extends User class when instantiated.
 * Created by Eric on 9/24/2017.
 */

public class Admin extends User {

    /**
     * no argument constructor creates instance of
     * Admin class.
     */
    public Admin() {
    }


}
